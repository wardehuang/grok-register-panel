# -*- coding: utf-8 -*-
"""List / export registered accounts as email----password----sso."""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
ACCOUNTS_DIR = Path(os.environ.get("ACCOUNTS_DIR", str(ROOT / "accounts")))

_SKIP_NAMES = {
    ".gitkeep",
    "mail_credentials.txt",
    "sso_pending.txt",
    "sso_risk_rejected.txt",
    "sso_bfs_flagged.txt",
    "outlook_accounts.txt",
    "outlook_state.json",
    "outlook_rt_inventory.txt",
    "outlook_rt_inventory.txt.used",
}
_SKIP_PREFIXES = (
    "outlook_",
    "sso_",
)
_SKIP_SUFFIXES = (
    ".lock",
    ".used",
    ".claims",
)


class RegisteredAccountsError(ValueError):
    pass


def _is_skipped(path: Path) -> bool:
    name = path.name
    if name in _SKIP_NAMES:
        return True
    if name.startswith("."):
        return True
    for p in _SKIP_PREFIXES:
        if name.startswith(p):
            return True
    for s in _SKIP_SUFFIXES:
        if name.endswith(s):
            return True
    if path.is_dir():
        return True
    return False


def _parse_line(line: str) -> dict[str, str] | None:
    raw = str(line or "").strip()
    if not raw or raw.startswith("#"):
        return None
    parts = raw.split("----")
    if len(parts) < 3:
        return None
    email = parts[0].strip()
    password = parts[1]
    sso = "----".join(parts[2:]).strip()
    if sso.startswith("sso="):
        sso = sso[4:]
    if "@" not in email or not password or not sso:
        return None
    return {
        "email": email,
        "password": password,
        "sso": sso,
        "line": f"{email}----{password}----{sso}",
    }


def _iter_candidate_files(directory: Path) -> list[Path]:
    if not directory.is_dir():
        return []
    out: list[Path] = []
    for path in directory.iterdir():
        if not path.is_file():
            continue
        if _is_skipped(path):
            continue
        if path.suffix.lower() != ".txt":
            continue
        out.append(path)
    return sorted(out, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)


def collect_registered_accounts(*, limit: int = 20000) -> dict[str, Any]:
    keep = max(1, min(100000, int(limit or 20000)))
    directory = ACCOUNTS_DIR
    by_email: dict[str, dict[str, Any]] = {}
    sources = 0

    for path in _iter_candidate_files(directory):
        sources += 1
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = None
        for line in text.splitlines():
            item = _parse_line(line)
            if not item:
                continue
            key = item["email"].casefold()
            prev = by_email.get(key)
            # prefer newer mtime; same file last line wins if equal
            if prev is None or (mtime or 0) >= (prev.get("mtime") or 0):
                by_email[key] = {
                    **item,
                    "source": path.name,
                    "mtime": mtime,
                }

    rows = sorted(
        by_email.values(),
        key=lambda r: (r.get("mtime") or 0, str(r.get("email") or "").lower()),
        reverse=True,
    )
    total = len(rows)
    rows = rows[:keep]
    lines = [str(r["line"]) for r in rows]
    # list view: no secrets
    public_rows = [
        {
            "email": r["email"],
            "source": r.get("source") or "",
            "mtime": r.get("mtime"),
            "has_password": bool(r.get("password")),
            "has_sso": bool(r.get("sso")),
            "sso_preview": (str(r.get("sso") or "")[:18] + "…") if r.get("sso") else "",
        }
        for r in rows
    ]
    return {
        "ok": True,
        "path": "accounts/",
        "abs_path": str(directory.resolve()),
        "exists": directory.is_dir(),
        "count": total,
        "source_files": sources,
        "truncated": total > len(rows),
        "accounts": public_rows,
        "export_filename": "registered_emails.txt",
        "export_text": "\n".join(lines) + ("\n" if lines else ""),
        "format": "email----password----sso",
    }


def export_registered_emails_text(*, limit: int = 20000) -> dict[str, Any]:
    data = collect_registered_accounts(limit=limit)
    return {
        "ok": True,
        "filename": data["export_filename"],
        "count": data["count"],
        "bytes": len(data["export_text"].encode("utf-8")),
        "text": data["export_text"],
        "format": data["format"],
    }


def read_one_registered_line(email: str) -> dict[str, Any]:
    target = str(email or "").strip()
    if not target or "@" not in target:
        raise RegisteredAccountsError("email 无效")
    data = collect_registered_accounts(limit=100000)
    key = target.casefold()
    for row in data.get("accounts") or []:
        # public rows don't have line — re-collect from export
        pass
    # re-scan for exact
    for path in _iter_candidate_files(ACCOUNTS_DIR):
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for line in text.splitlines():
            item = _parse_line(line)
            if not item:
                continue
            if item["email"].casefold() == key:
                return {
                    "ok": True,
                    "email": item["email"],
                    "line": item["line"],
                    "source": path.name,
                }
    raise RegisteredAccountsError("未找到该账号")
