"""Per-launch session log under log/runs/.

One file per batch/task start (not per account, not per supervisor child restart):
  log/runs/run_batch_YYYYMMDD_HHMMSS.log
  log/runs/run_cli_YYYYMMDD_HHMMSS.log
  log/runs/run_gui_YYYYMMDD_HHMMSS.log

Parent owns the file (writes header + final summary).
Children attach via env GROK_RUN_LOG and only append.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, TextIO

from secure_files import atomic_write_json

_ROOT = Path(__file__).resolve().parent
LOGS_DIR = _ROOT / "log" / "runs"
RUN_LOG_ENV = "GROK_RUN_LOG"
RUN_STATS_ENV = "GROK_RUN_STATS"

_lock = threading.Lock()
_file_handle: TextIO | None = None
_log_path: Path | None = None
_stats_path: Path | None = None
_is_owner: bool = False
_kind: str = "run"
_started_mono: float | None = None
_started_wall: str = ""

_TS_PREFIX_RE = re.compile(
    r"^\[\d{1,2}:\d{2}:\d{2}\]|^\[\d{4}-\d{2}-\d{2}[ T]\d{1,2}:\d{2}:\d{2}\]"
)


def _ensure_layout() -> None:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)


def _now_hms() -> str:
    try:
        from runtime_platform import beijing_strftime

        return beijing_strftime("%H:%M:%S")
    except Exception:
        return datetime.now().strftime("%H:%M:%S")


def _now_iso() -> str:
    try:
        from runtime_platform import beijing_strftime

        return beijing_strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return datetime.now().isoformat(timespec="seconds")


def _stamp_text(line: str) -> str:
    text = str(line or "")
    if not text:
        return ""
    ends_nl = text.endswith("\n")
    parts = text.splitlines()
    ts = _now_hms()
    out: list[str] = []
    for part in parts:
        if not part:
            out.append("")
            continue
        if _TS_PREFIX_RE.match(part):
            out.append(part)
        else:
            out.append(f"[{ts}] {part}")
    body = "\n".join(out)
    if ends_nl or body:
        body = body + "\n"
    return body


def _safe_kind(kind: str) -> str:
    return (
        "".join(
            c
            for c in str(kind or "run").strip().lower()
            if c.isalnum() or c in ("-", "_")
        )
        or "run"
    )


def _default_stats(kind: str, path: Path) -> dict[str, Any]:
    return {
        "kind": kind,
        "path": str(path),
        "started_at": _now_iso(),
        "ended_at": "",
        "reason": "",
        "reason_class": "",  # active | passive
        "target": 0,
        "completed": 0,
        "success": 0,
        "fail": 0,
        "restarts": 0,
        "fail_stats": {},
        "notes": [],
    }


def _stats_file_for(log_path: Path) -> Path:
    return log_path.with_suffix(log_path.suffix + ".stats.json")


def _load_stats(path: Path | None) -> dict[str, Any]:
    if path is None or not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write_stats(path: Path | None, data: dict[str, Any]) -> None:
    if path is None:
        return
    try:
        atomic_write_json(path, data)
    except Exception:
        try:
            path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        except Exception:
            pass


def update_run_stats(**fields: Any) -> None:
    """Merge counters into the shared stats sidecar (multi-process safe-ish)."""
    global _stats_path
    path_raw = str(os.environ.get(RUN_STATS_ENV, "") or "").strip()
    path = Path(path_raw) if path_raw else _stats_path
    if path is None and _log_path is not None:
        path = _stats_file_for(_log_path)
    if path is None:
        return
    with _lock:
        data = _load_stats(path)
        if not data:
            data = _default_stats(_kind, _log_path or path)
        for key, value in fields.items():
            if key == "fail_stats" and isinstance(value, dict):
                merged = dict(data.get("fail_stats") or {})
                for fk, fv in value.items():
                    try:
                        merged[str(fk)] = int(merged.get(str(fk), 0) or 0) + int(fv or 0)
                    except Exception:
                        merged[str(fk)] = fv
                data["fail_stats"] = merged
            elif key == "notes":
                notes = list(data.get("notes") or [])
                if isinstance(value, (list, tuple)):
                    notes.extend(str(v) for v in value)
                elif value:
                    notes.append(str(value))
                data["notes"] = notes[-50:]
            elif key in {"success", "fail", "completed", "restarts", "target"}:
                try:
                    # absolute set if provided as tuple ("set", n) else max/add via set
                    data[key] = int(value)
                except Exception:
                    data[key] = value
            elif value is not None:
                data[key] = value
        data["updated_at"] = _now_iso()
        _write_stats(path, data)
        _stats_path = path
        os.environ[RUN_STATS_ENV] = str(path)


def current_run_log_path() -> Path | None:
    with _lock:
        if _log_path is not None:
            return _log_path
    env = str(os.environ.get(RUN_LOG_ENV, "") or "").strip()
    return Path(env) if env else None


def attach_run_log(path: str | os.PathLike[str], kind: str | None = None) -> Path:
    """Append to an existing launch log (child / secondary process)."""
    global _file_handle, _log_path, _stats_path, _is_owner, _kind, _started_mono, _started_wall
    target = Path(path).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    with _lock:
        if _file_handle is not None and _log_path == target:
            return target
        if _file_handle is not None:
            try:
                _file_handle.flush()
                _file_handle.close()
            except Exception:
                pass
            _file_handle = None
        handle = target.open("a", encoding="utf-8", newline="\n")
        _file_handle = handle
        _log_path = target
        _stats_path = _stats_file_for(target)
        _is_owner = False
        if kind:
            _kind = _safe_kind(kind)
        os.environ[RUN_LOG_ENV] = str(target)
        os.environ[RUN_STATS_ENV] = str(_stats_path)
        if _started_mono is None:
            _started_mono = time.monotonic()
            _started_wall = _now_iso()
        try:
            handle.write(
                f"[{_now_hms()}] ----- child attach pid={os.getpid()} kind={_kind} -----\n"
            )
            handle.flush()
        except Exception:
            pass
    return target


def start_run_log(kind: str = "gui", *, force_new: bool = False) -> Path:
    """Open the launch log.

    - If GROK_RUN_LOG is set (or a log already open) and force_new is False: attach/reuse.
    - Else create one new file for this launch (owner).
    """
    global _file_handle, _log_path, _stats_path, _is_owner, _kind, _started_mono, _started_wall
    env_path = str(os.environ.get(RUN_LOG_ENV, "") or "").strip()
    if not force_new:
        if _file_handle is not None and _log_path is not None:
            return _log_path
        if env_path:
            return attach_run_log(env_path, kind=kind)

    _ensure_layout()
    safe = _safe_kind(kind)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = LOGS_DIR / f"run_{safe}_{stamp}.log"
    stats_path = _stats_file_for(path)

    with _lock:
        if _file_handle is not None:
            try:
                _file_handle.flush()
                _file_handle.close()
            except Exception:
                pass
            _file_handle = None
        handle = path.open("a", encoding="utf-8", newline="\n")
        header = (
            f"===== run start kind={safe} "
            f"at {_now_hms()} / {_now_iso()} pid={os.getpid()} =====\n"
        )
        handle.write(header)
        handle.flush()
        _file_handle = handle
        _log_path = path
        _stats_path = stats_path
        _is_owner = True
        _kind = safe
        _started_mono = time.monotonic()
        _started_wall = _now_iso()
        os.environ[RUN_LOG_ENV] = str(path)
        os.environ[RUN_STATS_ENV] = str(stats_path)
        _write_stats(stats_path, _default_stats(safe, path))
    return path


def ensure_run_log(kind: str = "cli") -> Path:
    """Prefer attach-to-launch; create only if this process is standalone."""
    return start_run_log(kind, force_new=False)


def append_run_log(line: str) -> None:
    text = _stamp_text(line)
    if not text:
        return
    # auto-attach if env points at a file but handle closed
    if _file_handle is None:
        env_path = str(os.environ.get(RUN_LOG_ENV, "") or "").strip()
        if env_path:
            try:
                attach_run_log(env_path)
            except Exception:
                pass
    with _lock:
        handle = _file_handle
        if handle is None:
            return
        try:
            handle.write(text)
            handle.flush()
        except Exception:
            pass


def _reason_class(reason: str) -> str:
    r = str(reason or "").strip().lower()
    active_tokens = (
        "user_stop",
        "user",
        "stop",
        "cancel",
        "cancelled",
        "sigint",
        "sigterm",
        "panel_stop",
        "active",
    )
    if any(t in r for t in active_tokens):
        return "active"
    return "passive"


def _format_summary(stats: dict[str, Any]) -> str:
    reason = str(stats.get("reason") or "unknown")
    rclass = str(stats.get("reason_class") or _reason_class(reason))
    label = "主动停止" if rclass == "active" else "被动停止/结束"
    duration = stats.get("duration_sec")
    try:
        dur_s = f"{float(duration):.0f}s"
    except Exception:
        dur_s = "-"
    fail_stats = stats.get("fail_stats") or {}
    fail_part = ""
    if isinstance(fail_stats, dict) and fail_stats:
        fail_part = " | " + ", ".join(f"{k}={v}" for k, v in fail_stats.items())
    notes = stats.get("notes") or []
    note_lines = ""
    if notes:
        note_lines = "\n".join(f"  - {n}" for n in notes[-10:])
        note_lines = f"\nnotes:\n{note_lines}"
    return (
        f"===== RUN SUMMARY ({label}) =====\n"
        f"reason: {reason} ({rclass})\n"
        f"started: {stats.get('started_at') or '-'}\n"
        f"ended:   {stats.get('ended_at') or _now_iso()}\n"
        f"duration: {dur_s}\n"
        f"target: {stats.get('target', 0)} | completed_slots: {stats.get('completed', 0)}\n"
        f"success: {stats.get('success', 0)} | fail: {stats.get('fail', 0)}"
        f"{fail_part}\n"
        f"restarts: {stats.get('restarts', 0)}\n"
        f"log: {stats.get('path') or ''}"
        f"{note_lines}\n"
        f"===== END SUMMARY =====\n"
    )


def finalize_run_log(
    reason: str = "completed",
    *,
    stats: dict[str, Any] | None = None,
    extra_lines: list[str] | None = None,
) -> Path | None:
    """Write end summary and close. Owner preferred; any process may finalize once."""
    global _file_handle, _log_path, _stats_path, _is_owner, _started_mono

    path = current_run_log_path()
    if path is None:
        return None

    # ensure handle
    if _file_handle is None:
        try:
            attach_run_log(path)
        except Exception:
            pass

    stats_path = _stats_path or _stats_file_for(path)
    data = _load_stats(stats_path) or _default_stats(_kind, path)
    if stats:
        data.update({k: v for k, v in stats.items() if v is not None})
    data["reason"] = str(reason or "unknown")
    data["reason_class"] = _reason_class(data["reason"])
    data["ended_at"] = _now_iso()
    if _started_mono is not None:
        data["duration_sec"] = max(0.0, time.monotonic() - _started_mono)
    elif data.get("started_at"):
        data["duration_sec"] = None
    data["path"] = str(path)
    _write_stats(stats_path, data)

    summary = _format_summary(data)
    with _lock:
        handle = _file_handle
        try:
            if handle is not None:
                if extra_lines:
                    for line in extra_lines:
                        handle.write(_stamp_text(line))
                handle.write(summary)
                handle.write(
                    f"===== run end at {_now_hms()} / {_now_iso()} "
                    f"reason={data['reason']} =====\n"
                )
                handle.flush()
                handle.close()
        except Exception:
            try:
                if handle is not None:
                    handle.close()
            except Exception:
                pass
        _file_handle = None
        # keep env so late readers still know path; clear owner
        _is_owner = False
        _started_mono = None
    return path


def stop_run_log() -> Path | None:
    """Close local handle.

    Owner finalizes with reason=process_exit if no prior finalize.
    Non-owner (child) only closes handle so parent keeps one log.
    """
    global _file_handle, _is_owner
    with _lock:
        owner = _is_owner
        path = _log_path
        handle = _file_handle
    if owner:
        # avoid double summary if already finalized
        stats_path = _stats_path or (_stats_file_for(path) if path else None)
        data = _load_stats(stats_path)
        if data.get("ended_at"):
            with _lock:
                if _file_handle is not None:
                    try:
                        _file_handle.close()
                    except Exception:
                        pass
                    _file_handle = None
            return path
        return finalize_run_log("process_exit")
    with _lock:
        if handle is not None:
            try:
                handle.flush()
                handle.close()
            except Exception:
                pass
            _file_handle = None
        _is_owner = False
    return path
