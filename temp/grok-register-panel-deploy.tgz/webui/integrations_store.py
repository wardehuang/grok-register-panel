# -*- coding: utf-8 -*-
"""Panel settings for CPA remote + grok2api remote + intervals/alias caps."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from secure_files import atomic_write_json, exclusive_file_lock

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = Path(os.environ.get("EMAIL_PROVIDER_CONFIG_FILE", str(ROOT / "config.json")))
LOCK_PATH = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + ".lock")

SECRET_KEYS = {
    "cpa_management_key",
    "grok2api_remote_password",
    "grok2api_remote_app_key",
}

PUBLIC_KEYS = [
    "account_interval",
    "register_interval_sec",
    "outlook_aliases_per_account",
    "outlook_use_alias_pool",
    "outlook_accounts_file",
    "outlook_state_file",
    "proxy_cursor_enabled",
    "proxy_pool_file",
    "proxy_pool_state_file",
    "skip_connectivity_precheck",
    "skip_xai_signup_precheck",
    "cpa_auto_add",
    "cpa_remote_url",
    "cpa_auth_dir",
    "grok2api_auto_add_remote",
    "grok2api_remote_base",
    "grok2api_remote_username",
    "grok2api_auth_dir",
]


class IntegrationConfigError(ValueError):
    pass


def _load() -> dict:
    if not CONFIG_PATH.is_file():
        return {}
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        raise IntegrationConfigError(f"读取 config.json 失败: {exc}") from exc
    if not isinstance(raw, dict):
        raise IntegrationConfigError("config.json 不是对象")
    return raw


def read_public_config() -> dict:
    data = _load()
    out: dict[str, Any] = {}
    for key in PUBLIC_KEYS:
        out[key] = data.get(key, "")
    out["secret_configured"] = {k: bool(str(data.get(k) or "").strip()) for k in SECRET_KEYS}
    # never return secrets
    return out


def save_integration_config(settings: dict, clear_secrets: list | None = None) -> dict:
    if not isinstance(settings, dict):
        raise IntegrationConfigError("settings 必须是对象")
    clear = {str(x).strip() for x in (clear_secrets or []) if str(x).strip()}
    with exclusive_file_lock(LOCK_PATH):
        data = _load()
        for key in PUBLIC_KEYS:
            if key not in settings:
                continue
            val = settings.get(key)
            if key in {
                "outlook_use_alias_pool",
                "proxy_cursor_enabled",
                "skip_connectivity_precheck",
                "skip_xai_signup_precheck",
                "cpa_auto_add",
                "grok2api_auto_add_remote",
            }:
                if isinstance(val, str):
                    data[key] = val.strip().lower() in ("1", "true", "yes", "on")
                else:
                    data[key] = bool(val)
            elif key in {"outlook_aliases_per_account", "register_interval_sec", "grok2api_remote_retries"}:
                try:
                    data[key] = int(val or 0)
                except Exception as exc:
                    raise IntegrationConfigError(f"{key} 必须是整数") from exc
            else:
                data[key] = str(val or "").strip()
        for key in SECRET_KEYS:
            if key in clear:
                data[key] = ""
                continue
            if key not in settings:
                continue
            val = str(settings.get(key) or "").strip()
            if val:
                data[key] = val
            # empty means keep existing
        atomic_write_json(CONFIG_PATH, data)
    return read_public_config()


def latest_run_log_tail(max_lines: int = 200) -> dict:
    runs = ROOT / "log" / "runs"
    if not runs.is_dir():
        return {"path": "", "lines": [], "missing": True}
    files = sorted(runs.glob("run_*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        # also try batch-orch logs
        log_dir = ROOT / "log"
        files = sorted(log_dir.glob("batch-orch-*.log"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        return {"path": "", "lines": [], "missing": True}
    path = files[0]
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        return {"path": str(path), "lines": [f"read error: {exc}"], "missing": False}
    lines = text.splitlines()
    keep = max(20, min(2000, int(max_lines or 200)))
    return {
        "path": str(path.relative_to(ROOT)) if str(path).startswith(str(ROOT)) else str(path),
        "lines": lines[-keep:],
        "missing": False,
        "total_lines": len(lines),
    }
