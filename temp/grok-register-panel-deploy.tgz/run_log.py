"""Per-run session log files under log/runs/.

One file per registration run:
  log/runs/run_gui_YYYYMMDD_HHMMSS.log
  log/runs/run_cli_YYYYMMDD_HHMMSS.log

Thread-safe append; call start_run_log() once at run begin and stop_run_log() at end.
"""

from __future__ import annotations

import threading
from datetime import datetime
from pathlib import Path
from typing import TextIO

# Panel layout: repository root / log / runs
_ROOT = Path(__file__).resolve().parent
LOGS_DIR = _ROOT / "log" / "runs"

_lock = threading.Lock()
_file_handle: TextIO | None = None
_log_path: Path | None = None


def _ensure_layout() -> None:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)


def start_run_log(kind: str = "gui") -> Path:
    """Open a new session log file. Closes any previous open session first."""
    global _file_handle, _log_path
    _ensure_layout()
    safe_kind = "".join(
        character
        for character in str(kind or "run").strip().lower()
        if character.isalnum() or character in ("-", "_")
    ) or "run"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = LOGS_DIR / f"run_{safe_kind}_{stamp}.log"
    with _lock:
        if _file_handle is not None:
            try:
                _file_handle.flush()
                _file_handle.close()
            except Exception:
                pass
            _file_handle = None
        handle = path.open("a", encoding="utf-8", newline="\n")
        header = (
            f"===== run start kind={safe_kind} "
            f"at {datetime.now().isoformat(timespec='seconds')} =====\n"
        )
        handle.write(header)
        handle.flush()
        _file_handle = handle
        _log_path = path
    return path


def append_run_log(line: str) -> None:
    """Append one log line (adds trailing newline if missing). No-op if no session."""
    text = str(line or "")
    if not text:
        return
    if not text.endswith("\n"):
        text = text + "\n"
    with _lock:
        handle = _file_handle
        if handle is None:
            return
        try:
            handle.write(text)
            handle.flush()
        except Exception:
            pass


def current_run_log_path() -> Path | None:
    with _lock:
        return _log_path


def stop_run_log() -> Path | None:
    """Close the current session log. Returns path if one was open."""
    global _file_handle, _log_path
    with _lock:
        path = _log_path
        handle = _file_handle
        _file_handle = None
        _log_path = None
        if handle is None:
            return path
        try:
            handle.write(
                f"===== run end at {datetime.now().isoformat(timespec='seconds')} =====\n"
            )
            handle.flush()
            handle.close()
        except Exception:
            try:
                handle.close()
            except Exception:
                pass
        return path
